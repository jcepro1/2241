﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examensb
{
    class NEnt
    {
    
        private int n;


        public NEnt()
        {
            n = 0;
        }


        public void cargar(int dato)
        {
            n = dato;
        }

        public bool verifprimo()
        {
            int c, i, r;
            c = 0;
            for (i = 1; i <= n; i = i + 1)
            {
                r = n % i;
                if (r == 0)
                    c++;
            }

            return (c == 2);

        }
    }
}
